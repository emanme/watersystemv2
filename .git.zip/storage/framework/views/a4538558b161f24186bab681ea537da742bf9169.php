

<?php $__env->startSection('title', 'Meter Services'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mt-3">
        <div class="row">
            <div class="col-12 col-sm-8 col-md-6 col-lg-6 form-search d-lg-block d-md-none hidden pt-1">
                <form action="<?php echo e(route('admin.services-search-customer')); ?>" method="get" class="d-flex justify-content-between align-items-center mb-lg-0">
                    <input type="text" class="form-control" name="account_number" placeholder="Search for an Account #">
                    <button class="btn btn-primary ms-1 d-flex justify-content-between align-items-center" id="close"><i data-feather="search" class="feather-18 me-1"></i> Search</button>
                </form>
            </div>
        </div>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger pb-0">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(isset($customer)): ?>
        <h6 class="text-secondary ps-1 d-block d-lg-none pt-2" style="font-size: 17px !important;"><strong>CLIENT : <?php echo e(isset($customer)?strtoUpper($customer["org_name"])?strtoupper($customer["org_name"]):strtoupper($customer["fullname"]):''); ?></strong></h6>
        <h6 class="text-secondary ps-1 d-block d-lg-none pb-2" style="font-size: 15px !important;"><strong>ACCOUNT NO : <span class="text-primary"><?php echo e(isset($customer) ? $customer["account"] : ''); ?></span></strong></h6>
        <?php endif; ?>
        <div class="row">
            <div class="col-12 col-sm-8 col-md-6">
                <div class="card bg-white mt-md-2">
                    <div class="card-header pt-3 pb-2 bg-white d-none d-lg-block">
                        <h6 class="text-secondary d-flex justify-content-start align-items-center"><span>CLIENT &nbsp;:</span> <span class="text-primary ms-2"><?php echo e(isset($customer)?strtoUpper($customer["org_name"])?strtoupper($customer["org_name"]):strtoupper($customer["fullname"]):''); ?></span></h6>
                        <h6 class="text-secondary d-flex justify-content-start align-items-center"><span>ACC. # &nbsp; :</span> <span class="text-primary ms-2" id="acc_num"><?php echo e(isset($customer) ? $customer["account"] : ''); ?></span></h6>
                    </div>
                    <div class="card-body pt-3 pb-2 px-3">
                        <form id="waterworks_form" action="<?php echo e(route('admin.meter-services.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <p class="text-danger pt-1">Reminder: Fields with (*) is required.</p>
                            <h3 class="text-muted mt-4"><strong>Water Works Services </strong></h3>
                            <div class="row mt-4 mb-2 ps-4 pe-4">
                                <p class="mb-0">Select service(s) <span class="text-danger">*</span></p>
                                <div class="ms-4">
                                    <h6 class="d-flex justify-content-start align-items-center py-0 my-0"><input type="radio" name="type_of_service" id="" value="request_for_transfer_of_meter" class="me-2 mt-1">Request for transfer of meter</h6>
                                    <h6 class="d-flex justify-content-start align-items-center py-0 my-0"><input type="radio" name="type_of_service" id="" value="change_of_meter" class="me-2 mt-1">Change of meter</h6>
                                    <h6 class="d-flex justify-content-start align-items-center py-0 my-0"><input type="radio" name="type_of_service" id="" value="change_of_ownership" class="me-2 mt-1">Change of ownership</h6>
                                    <h6 class="d-flex justify-content-start align-items-center py-0 my-0"><input type="radio" name="type_of_service" id="" value="disconnection"class="me-2 mt-1">Disconnection</h6>
                                    <h6 class="d-flex justify-content-start align-items-center py-0 my-0"><input type="radio" name="type_of_service" id="" value="repairs_of_damage_connection" class="me-2 mt-1">Repairs of damage connection (from main line to meter only)</h6>
                                    <h6 class="d-flex justify-content-start align-items-center py-0 my-0"><input type="radio" name="type_of_service" id="" value="report_of_no_water_low_pressure" class="me-2 mt-1">Report of no water, low pressure</h6>
                                    <h6 class="d-flex justify-content-start align-items-center py-0 my-0"><input type="radio" name="type_of_service" id="" value="defective_meter_and_other_related_request" class="me-2 mt-1">Defective meter and other related request.</h6>
                                    <!-- <h6 class="d-flex justify-content-start align-items-center py-0 my-0"><input type="checkbox" name="" id="" class="me-2 mt-1"></h6>
                                    <h6 class="d-flex justify-content-start align-items-center py-0 my-0"><input type="checkbox" name="" id="" class="me-2 mt-1"></h6> -->
                                </div>
                            </div>
                            
                        </form>
                    </div>
                </div>
                <?php if(!isset($customer)): ?>
                
                <?php endif; ?>
                <?php if(isset($customer)): ?>
                <div class="row mt-3">
                    <div class="col-xs-12 d-flex justify-content-start align-items-center mt-1">
                        <button class="btn btn-primary d-flex justify-content-between align-items-center" id="request_waterworks_btn" ><i data-feather="arrow-right" class="feather-18 me-2"></i> Send Request</button>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-js'); ?>

<script>


    request_waterworks_btn.addEventListener('click', async(e)=>{
        // e.preventDefault();
        let data = new FormData(waterworks_form)
        data.append('account_number', acc_num.textContent)
        let url = waterworks_form.getAttribute('action');

        // data.forEach((datas) => console.log(datas));

        let response = await fetch(url,{
            method: 'post',
            body: data
        });

        response = await response.json();
        if(response.created == true){
            Swal.fire('Great!','Service request successfully sent!','success').then(function(result){
                if(result.isConfirmed)
                {
                    window.location.reload();
                }
            })
        }else{
            Swal.fire('Something went wrong!','Please be sure to fill up all the required fields','error');
        }

    })
</script>

<script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script src="<?php echo e(asset('assets/js/form-search-animation.js')); ?>" defer></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('field-personnel.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/southernleyteorg/watersystemv2_app/resources/views/field-personnel/pages/services.blade.php ENDPATH**/ ?>