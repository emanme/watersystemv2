
<?php $__env->startSection('title', 'New Service'); ?>

<?php $__env->startSection('content'); ?>

<h4 class="mt-3 mb-4"><i data-feather="tool" class=""></i> Add New Service</h4>


<div class="row justify-content-center">
    <div class="col-12 col-md-4 ">
        <form action="<?php echo e(route('admin.services.search')); ?>" method="get">
            <div class="input-group mb-3">
                    <input name="account_number" type="text" class="form-control <?php $__errorArgs = ['account_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    placeholder="Account #"
                    value="<?php echo e(old('account_number')?old('account_number'):(isset($customer)?$customer->account_number:'')); ?>"
                    required>
                    <button class="btn btn-primary" type="submit" id="button-addon2">Search</button>
                    <?php $__errorArgs = ['account_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </form>
        <div class="mt-4">
            <small class="text-muted">New Account?</small>
            <a href="<?php echo e(route('admin.new-connection.create')); ?>" class="btn btn-outline-secondary btn-sm">Create New Connection</a>
        </div>
    </div>
    <div class="col-12 col-md-8">
        <?php if(session('created')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Great!</strong> <?php echo e(session('message')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <?php if(isset($customer)): ?>
        <form action="<?php echo e(route('admin.services.store')); ?>" method="post">
            <?php echo csrf_field(); ?>

            <input type="text" name='account_number' value="<?php echo e($customer->account_number); ?>" hidden/>
            <h5>Applicant Information</h5>
            <hr>

            <div class="row">
                <div class="col">
                    <small class="text-muted">Name</small>
                    <h6><?php echo e($customer->fullname()); ?></h6>
                </div>
                <div class="col">
                    <small class="text-muted">Civil Status</small>
                    <h6><?php echo e($customer->civilStatus()); ?></h6>
                </div>
                <div class="col">
                    <small class="text-muted">Connection Type</small>
                    <h6><?php echo e($customer->connectionType()); ?></h6>
                </div>
                <div class="col">
                    <small class="text-muted">Contact #</small>
                    <h6><?php echo e($customer->contact_number); ?></h6>
                </div>

            </div>

            <small class="text-muted">Service Type</small>
            <select class="form-select form-select-sm  <?php $__errorArgs = ['service_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="service_type" required>

                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value=>$name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($value); ?>  <?php if($value==old('service_type')): ?>selected <?php endif; ?>><?php echo e($name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['service_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <small class="text-muted">Remarks</small>
            <textarea class="form-control <?php $__errorArgs = ['remarks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="3" name="remarks"></textarea>
            <?php $__errorArgs = ['remarks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


            <div class="row mt-3">
                <div class="col-12 col-lg-6">
                    <small class="text-muted mt-4">Address</small>
                    <h6><?php echo e($customer->address()); ?></h6>
                </div>
                <div class="col-12 col-lg-6">
                    <small class="text-muted">Landmark</small>
                    <input class="form-control" type="text" name="landmark" />
                </div>

            </div>

            <div class="row">
                <div class="col-12 col-md-8 col-lg-5">
                    <small class="text-muted">Service Schedule</small>
                    <input class="form-control  <?php $__errorArgs = ['service_schedule'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="date" name="service_schedule" required/>
                    <?php $__errorArgs = ['service_schedule'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>


            <button type="submit" class="btn btn-primary mt-3">Submit</button>

        </form>
        <?php else: ?>
                <p class="text-info text-center"> <i data-feather="alert-circle"></i> Please search for an Account Number first</p>
        <?php endif; ?>

    </div>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jv file\websites\watersystemv2\resources\views/pages/add-service.blade.php ENDPATH**/ ?>