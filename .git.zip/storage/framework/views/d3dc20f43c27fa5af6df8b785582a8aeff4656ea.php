
<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="justify-content-center mx-3 my-5 ms-lg-0">
    <h1 class="text-center mt-3">Welcome ! <?php echo e(Auth::user()->name); ?></h1>
    <h2 class="text-center mt-3" style="letter-spacing: 0.07rem; font-weight: 400;"><span id="date" class="me-3"></span>|<span id="time" class="ms-3"></span></h2>
    <!-- <h3 class="text-center" id="time" style="letter-spacing: 0.07rem;"></h3> -->
    <div class="row mt-4">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if (isset($component)) { $__componentOriginal472e74d7725fa1e3f68758e82c47c002df221f33 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\DashboardCard::class, ['title' => $datum['title'],'count' => $datum['count'],'url' => $datum['url'],'icon' => $datum['icon']]); ?>
<?php $component->withName('dashboard-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
         <?php if (isset($__componentOriginal472e74d7725fa1e3f68758e82c47c002df221f33)): ?>
<?php $component = $__componentOriginal472e74d7725fa1e3f68758e82c47c002df221f33; ?>
<?php unset($__componentOriginal472e74d7725fa1e3f68758e82c47c002df221f33); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<script>
    startTime()

    function formatAMPM(date) {
        var hours = date.getHours();
        var minutes = date.getMinutes();
        var seconds = date.getSeconds();
        var ampm = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12;
        hours = hours ? hours : 12;
        minutes = minutes < 10 ? '0'+ minutes : minutes;
        seconds = seconds < 10 ? '0'+ seconds : seconds;
        var strTime = hours + ':' + minutes + ':' + seconds + ' ' + ampm;
        return strTime;
    }

    function startTime() {
        document.getElementById('time').innerHTML = formatAMPM(new Date());
        setTimeout(startTime, 1000);
    }

    var date =  new Date()
    var newDate = date.toDateString().split(' '),
        cleanDate = date.toLocaleString('default', { month: 'long' }) + ' ' + newDate[2] + ', ' + newDate[3]

    document.getElementById('date').innerHTML = cleanDate
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/southernleyteorg/watersystemv2_app/resources/views/pages/dashboard.blade.php ENDPATH**/ ?>