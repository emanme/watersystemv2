<?php $__env->startSection('title', 'Pending for Completion'); ?>


<?php $__env->startSection('content'); ?>
<?php echo $__env->make('templates.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h3 class="mt-5 text-center"><i data-feather="check-square"></i> Pending for Completion</h3>
<?php if($services->count()>0): ?>
<div class="table-responsive mt-4 shadow-sm">
    <table class="table table-bordered mb-0">
        <thead class="table-dark">
            <th>Account #</th>
            <th>Client Name</th>
            <th>Request Type</th>
            <th>Date of Request</th>
            <th>Actions</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($service->customer->account_number); ?></td>
                <td><?php echo e($service->customer->fullname()); ?></td>
                <td><?php echo e($service->prettyType()); ?></td>
                <td><?php echo e($service->created_at); ?></td>
                <td>
                    <a href="<?php echo e(route('admin.waterworks.pending-for-completion.mark',$service)); ?>" class="btn btn-sm btn-success"><i data-feather="check"></i> Mark as done</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php else: ?>
<p class="text-center mt-5">
    <i data-feather="alert-circle"></i> No services that are pending for completion
</p>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.approval', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/southernleyteorg/watersystemv2_app/resources/views/pages/pending-for-completion.blade.php ENDPATH**/ ?>