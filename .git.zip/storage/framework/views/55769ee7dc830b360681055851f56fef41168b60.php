

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
HOME
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-js'); ?>

<script src="<?php echo e(asset('assets/js/form-search-animation.js')); ?>" defer></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('field-personnel.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jv file\websites\watersystemv2\resources\views/field-personnel/pages/home.blade.php ENDPATH**/ ?>