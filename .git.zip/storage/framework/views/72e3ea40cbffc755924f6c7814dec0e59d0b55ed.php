

<?php $__env->startSection('title', 'Customers'); ?>

<?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <h5 class="text-secondary h4"><i data-feather="align-right" class="mb-1 feather-30 me-1"></i> Lists of Consumers</h5>
    <div class="card border">
        <div class="card-header border-0 px-2 pb-0 pt-2 bg-white">
            <div class="row">
                <div class="col-lg-5 col-md-7 col-sm-8 pe-md-0 pe-md-5">
                    <form action="<?php echo e(route('admin.searched-customers.index')); ?>" class="mb-0" action="get">
                        <div class="input-group mb-2">
                            <input type="text" name='keyword' value="<?php echo e($keyword??''); ?>" class="form-control <?php $__errorArgs = ['keyword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter name or account #" aria-describedby="button-addon2">
                            <button class="btn btn-primary" type="submit" id="button-addon2"><i data-feather="search" class="feather-20 me-1"></i> Search</button>
                            <?php $__errorArgs = ['keyword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div id="validationServerUsernameFeedback" class="invalid-feedback">
                              <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </form>
                </div>
                <div class="col-lg-7 col-md-5 col-sm-4" align="right">
                    <?php if(isset($keyword)): ?>
                    <small>
                        <a class="btn btn-primary mb-3 pb-2 pt-2" href="<?php echo e(route('admin.customers')); ?>"><i data-feather="align-center" class="feather-20 mx-1 pb-1 pt-1"></i> Show all</a>
                    </small>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive border-top">
                <table class="table table-hover <?php echo e(($customers->count() < 10) ? 'mb-0' : ''); ?>">
                    <thead class="table-white">
                        <tr>
                            <th class="text-secondary py-3 border-bottom-0">ACCOUNT #</th>
                            <th class="text-secondary py-3 border-bottom-0">FULL NAME</th>
                            <th class="text-secondary py-3 border-bottom-0">CIVIL STATUS</th>
                            <th class="text-secondary py-3 border-bottom-0">CONTACT #</th>
                            <th class="text-secondary py-3 border-bottom-0">ADDRESS</th>
                            <th class="text-secondary py-3 border-bottom-0">CONNECTION TYPE</th>
                            <th class="text-secondary py-3 border-bottom-0">CONNECTION STATUS</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($customers->count()>0): ?>

                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr style="cursor: pointer;" onclick='location.href=`<?php echo e(route("admin.search-transactions", ["account_number" => $customer->account_number])); ?>`'>
                            <td class="text-primary border-top <?php echo e(($customers->count() < 2) ? 'border-bottom-0' : ''); ?> "><strong><?php echo e($customer->account_number); ?></strong></td>
                            <?php if($customer->isOrgAccount()): ?>
                            <td class="text-secondary border-secondary <?php echo e(($customers->count() < 2) ? 'border-bottom-0' : ''); ?> ">
                              ORG/COMPANY: <strong><?php echo e($customer->org_name); ?></strong><br>
                              <small class="text-muted">Registered by (<?php echo e($customer->fullname()); ?>)</small>
                            </td>
                            <?php else: ?>
                            <td class="text-secondary border-top <?php echo e(($customers->count() < 2) ? 'border-bottom-0' : ''); ?> "><?php echo e($customer->firstname . ' ' .$customer->middlename. ' '.$customer->lastname); ?></td>
                            <?php endif; ?>
                            
                            <td class="text-secondary border-top <?php echo e(($customers->count() < 2) ? 'border-bottom-0' : ''); ?> "><?php echo e(Str::ucfirst($customer->civil_status)); ?></td>
                            <td class="text-secondary border-top <?php echo e(($customers->count() < 2) ? 'border-bottom-0' : ''); ?> "><?php echo e($customer->contact_number); ?></td>
                            <td class="text-secondary border-top <?php echo e(($customers->count() < 2) ? 'border-bottom-0' : ''); ?> "><?php echo e($customer->purok.', '.$customer->barangay); ?></td>
                            <td class="text-secondary border-top <?php echo e(($customers->count() < 2) ? 'border-bottom-0' : ''); ?> "><?php echo e(Str::ucfirst($customer->connection_type)); ?></td>
                            <td class="text-secondary border-top <?php echo e(($customers->count() < 2) ? 'border-bottom-0' : ''); ?> "><?php echo e(Str::ucfirst($customer->connection_status)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <tr>
                          <td class="text-center text-secondary py-3 border-top <?php echo e(($customers->count() < 1) ? 'border-bottom-0' : ''); ?>" colspan="7"><i data-feather="user-x" class="feather-20 me-1"></i> No records to display</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                
            </div>
            
        </div>
   
    </div>
    
    <?php if($customers->count()>0): ?>
    <div class="pt-2">
        <a href="<?php echo e(route('admin.customers.export',['keyword'=>isset($keyword)?$keyword:''])); ?>" class="btn btn-secondary py-2"><i data-feather="download" class="feather-20 me-1 pb-1"></i> Export Data</a>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jv file\websites\watersystemv2\resources\views/pages/customers-list.blade.php ENDPATH**/ ?>