<a href="<?php echo e(route($url)); ?>" class="btn btn-secondary float-md-end ms-1" style="height: 45px; padding-top: 10px;"><?php echo e($btnText); ?></a>

<?php /**PATH /Users/ccsit/Desktop/website/watersystemv2/resources/views/components/button.blade.php ENDPATH**/ ?>