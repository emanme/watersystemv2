
<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="row justify-content-center mx-3 ms-lg-0">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if (isset($component)) { $__componentOriginal472e74d7725fa1e3f68758e82c47c002df221f33 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\DashboardCard::class, ['title' => $datum['title'],'count' => $datum['count'],'url' => $datum['url']]); ?>
<?php $component->withName('dashboard-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal472e74d7725fa1e3f68758e82c47c002df221f33)): ?>
<?php $component = $__componentOriginal472e74d7725fa1e3f68758e82c47c002df221f33; ?>
<?php unset($__componentOriginal472e74d7725fa1e3f68758e82c47c002df221f33); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jv file\websites\watersystemv2\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>