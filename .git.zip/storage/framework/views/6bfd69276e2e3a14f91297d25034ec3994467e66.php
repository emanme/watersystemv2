<div class="col-12 col-md-5 col-lg-2 card my-1 mt-2 me-md-2">
    <!-- Very little is needed to make a happy life. - Marcus Antoninus -->
    <div class="card-body text-end">
        <h3 class="card-title"><?php echo e($count); ?></h3>
        <p class="card-text"><?php echo e($title); ?></p>
        <a href="<?php echo e($url); ?>" class="stretched-link"></a>
    </div>
</div>
<?php /**PATH D:\jv file\websites\watersystemv2\resources\views/components/dashboard-card.blade.php ENDPATH**/ ?>