<?php $__env->startSection('title', 'Officers'); ?>

<?php $__env->startSection('content'); ?>

<div class="row mt-4">
  <div class="col-md-12 mt-3">
    <?php if(session('created')): ?>
    <div class="alert alert-success alert-dismissible fade show mt-4" role="alert">
        <strong>Great!</strong> <?php echo e(session('message')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    <div class="row">
      <div class="col-md-6">
        <h5 class="text-secondary h4 mt-4"><i data-feather="align-right" class="mb-1 feather-30 me-1"></i> Lists of Officers</h5>
      </div>
      <div class="col-md-6">
        <a class="btn btn-primary mb-3 pb-2 pt-2 mt-2 float-end" href="<?php echo e(route('admin.officers.create')); ?>"><i data-feather="user-plus" class="feather-20 mx-1 pb-1 pt-1"></i> New Officer</a>
      </div>
    </div>
    <div class="card">
      <div class="table-responsive mb-0">
        <table class="table mb-0">
            <thead>
              <tr>
                <td scope="col" class="border-bottom-0 py-3"><strong>FULL NAME</strong></td>
                <td scope="col" class="border-bottom-0 py-3"><strong>POSITION</strong></td>
                <td scope="col" class="border-bottom-0 py-3"><strong>ACTIONS</strong></td>
              </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $officers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $officer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                  <td scope="row" class="border-bottom-0 border-top"><?php echo e($officer->fullname); ?></td>
                  <td class="border-bottom-0 border-top"><?php echo e($officer->prettyPosition()); ?></td>
                  <td class="border-bottom-0 border-top">

                    <a href="<?php echo e(route('admin.officers.edit',$officer)); ?>">Edit</a>
                    <span> | </span>
                    <form action="<?php echo e(route('admin.officers.destroy',$officer)); ?>" method="post" style="display:inline">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field("DELETE"); ?>
                      <button type="submit" class="btn btn-link" onclick="return confirm('Are you sure you want to delete this officer? This cannot be reverted back.')">Delete</button>
                    </form>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                  <td colspan="3" class="text-center border-top border-bottom-0">No records yet!</td>
                </tr>
                <?php endif; ?>
            </tbody>
          </table>

      </div>

    </div>
    <?php echo e($officers->links()); ?>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ccsit/Desktop/website/watersystemv2/resources/views/pages/officers/index.blade.php ENDPATH**/ ?>