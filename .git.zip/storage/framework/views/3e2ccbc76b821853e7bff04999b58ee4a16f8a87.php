<?php $__env->startSection('title', 'Building Inspection Request'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-0">
    <?php echo $__env->make('templates.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-md-8 pt-2">
        <h3 class="h4 mb-3 mt-2 text-left text-secondary"><i data-feather="align-left" class="feather-16 mx-1"></i> <?php echo e($text[0]); ?></h3>
    </div>
    <div class="col-md-4"></div>
</div>

<div class="card shadow-sm">
    <div class="card-header px-2 bg-white pt-1 pb-0">
        <div class="row">
            <div class="col-md-6 py-0">
                <?php echo $__env->make('templates.form-search-account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <?php if(isset(request()->keyword)): ?>
                <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, ['url' => $index_route]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive p-0">
            <table class="table mb-0" style="min-width: 1300px !important">
                <thead class="bg-light">
                    <tr>
                        <td class="border-bottom pt-3 pb-3 text-secondary"><strong><i data-feather="bar-chart-2" class="mx-1 text-primary" width="18"></i> ACCOUNT NO</strong></td>
                        <td class="border-bottom pt-3 pb-3 text-secondary"><strong><i data-feather="user" class="mx-1 text-primary" width="18"></i> CLIENT NAME</strong></td>
                        <td class="border-bottom pt-3 pb-3 text-secondary"><strong><i data-feather="activity" class="mx-1 text-primary" width="18"></i> REQUEST TYPE</strong></td>
                        <td class="border-bottom pt-3 pb-3 text-secondary"><strong><i data-feather="calendar" class="mx-1 text-primary" width="18"></i> DATE OF REQUEST</strong></td>
                        <td class="border-bottom pt-3 pb-3 text-secondary"><strong><i data-feather="activity" class="mx-1 text-primary" width="20"></i> ACTIONS</strong></td>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($services) > 0): ?>
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="pt-2 pb-2 ps-3"><?php echo e($service->customer->account_number); ?></td>
                            <td class="pt-2 pb-2 ps-3"><?php echo e($service->customer->fullname()); ?> </td>
                            <td class="pt-2 pb-2 ps-3"><?php echo e($service->prettyServiceType()); ?></td>
                            <td class="pt-2 pb-2 ps-3"><?php echo e(\Carbon\Carbon::parse($service->created_at)->format('F d, Y')); ?></td>
                            <td class="d-flex justify-content-start py-0">
                                <?php if($service->status == 'pending_building_inspection'): ?>
                                <form action="<?php echo e(route('admin.bld-request-approvals-approve')); ?>" method="post" class="mb-0 mx-0 d-flex py-2">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($service->id); ?>">
                                    <button type="submit" class="border-0 bg-white text-primary"><i data-feather="check" width="20"></i> Approve</button>
                                </form>

                                <?php if($service->isDeniable()): ?>
                                <form action="<?php echo e(route('admin.bld-request-approvals-reject', ['id' => $service->id])); ?>" method="post" class="mb-1 mx-0">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="border-0 bg-white text-danger"><i data-feather="x" width="20"></i> Deny</button>
                                </form>
                                <?php endif; ?>
                                <?php else: ?>
                                <form action="<?php echo e(route('admin.undo-status', ['id' => $service->id])); ?>" method="post" class="mb-0 mx-0 py-2">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="border-0 bg-white text-danger"><i data-feather="repeat" width="18"></i>&nbsp; Undo</button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
            <div class="<?php echo e(count($services) > 0 ? 'pt-2 pb-2 px-2 bg-light' : 'pt-1 pb-1 px-2 bg-white'); ?>">
                <div class="pt-2 px-2 pb-1">
                    <?php if(count($services) > 0): ?>
                    <?php echo e($services->render()); ?>

                    <?php else: ?>
                    <h6 class="text-center text-secondary">No records to display</h6>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.approval', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jv file\websites\watersystemv2\resources\views/pages/bldg-request-approval.blade.php ENDPATH**/ ?>