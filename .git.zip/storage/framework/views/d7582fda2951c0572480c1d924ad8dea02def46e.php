  <nav class="navbar navbar-expand-md navabr-light border-bottom pt-3 pb-3">
    <div class="container<?php echo e(Request::is('admin/consumer-ledger*') || Request::is('admin/service-list*') ? '-fluid px-5' : ' px-3'); ?>">
      <a class="navbar-brand text-dark pe-4 pt-md-0" href="<?php echo e(route('admin.dashboard')); ?>"><strong>MWS</strong></a>
      <button class="navbar-toggler border-secondary" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span data-feather="align-center" class="text-secondary"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0 pt-lg-0 pt-md-2">
          <?php if (\Illuminate\Support\Facades\Blade::check('adminonly', Auth::user()->role)): ?>
          <li class="nav-item m1-">
            <a class="nav-link m-1 text-secondary" aria-current="page" href="<?php echo e(route('admin.dashboard')); ?>">
              <i data-feather="home" class="feather-16 m-1 mb-1"></i> Home
            </a>
          </li>
          <?php endif; ?>
          <li class="nav-item dropdown pt-1">
            <a class="nav-link dropdown-toggle text-secondary" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <i data-feather="users" class="feather-16 m-1"></i> Consumer
            </a>
            <ul class="dropdown-menu px-2" aria-labelledby="navbarDropdown">
              <li><a class="dropdown-item" href="<?php echo e(route('admin.existing-customers.create')); ?>">Data Entry</a></li>
              
              <li><a class="dropdown-item" href="<?php echo e(route('admin.existing-customers.index')); ?>">View Lists</a></li>
            </ul>
          </li>
          <?php if (\Illuminate\Support\Facades\Blade::check('cashierOnly', Auth::user()->role)): ?>
          <li class="nav-item m1-">
            <a class="nav-link m-1 text-secondary" aria-current="page" href="<?php echo e(route('admin.services-payment')); ?>">
              <i data-feather="activity" class="feather-16 m-1 mb-1"></i> Request Services &nbsp;
            </a>
          </li>
          <?php endif; ?>
          <?php if (\Illuminate\Support\Facades\Blade::check('adminonly', Auth::user()->role)): ?>
          
          <?php endif; ?>


          <?php if (\Illuminate\Support\Facades\Blade::check('adminonly', Auth::user()->role)): ?>
          <li class="nav-item dropdown pt-1">
            <a class="nav-link dropdown-toggle text-secondary" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
             <i data-feather="users" class="feather-16 m-1"></i> Accounts
            </a>
            <ul class="dropdown-menu px-2" aria-labelledby="navbarDropdown">
              <li>
                <a class="dropdown-item" href="<?php echo e(route('admin.users.create')); ?>">New</a>
                <a class="dropdown-item" href="<?php echo e(route('admin.users.index')); ?>">View</a>
                
              </li>
            </ul>
          </li>

          <li class="nav-item dropdown pt-1">
            <a class="nav-link text-secondary" href="<?php echo e(route('admin.officers.index')); ?>"  aria-expanded="false">
             <i data-feather="users" class="feather-16 m-1"></i> Officers
            </a>
          </li>
          <?php endif; ?>

          <?php if (\Illuminate\Support\Facades\Blade::check('adminonly', Auth::user()->role)): ?>
          <li class="nav-item dropdown pt-1">
            <a class="nav-link dropdown-toggle text-secondary" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
             <i data-feather="tool" class="feather-16 m-1"></i> Services
            </a>
            <ul class="dropdown-menu px-2" aria-labelledby="navbarDropdown">
              <li>
                <a class="dropdown-item" href="<?php echo e(route('admin.services.create')); ?>">New</a>
                <a class="dropdown-item" href="<?php echo e(route('admin.services.index')); ?>">List of Services</a>
                <a class="dropdown-item" href="<?php echo e(route('admin.request-approvals')); ?>">Requests</a>
              </li>
            </ul>
          </li>
          <?php endif; ?>


          <?php if (\Illuminate\Support\Facades\Blade::check('adminonly', Auth::user()->role)): ?>
          <li class="nav-item dropdown pt-1">
            <a class="nav-link dropdown-toggle text-secondary" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <i data-feather="settings" class="feather-16 m-1"></i> Settings
            </a>
            <ul class="dropdown-menu px-2" aria-labelledby="navbarDropdown">
              <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#exampleModal">Water Rates</a></li>
              <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#surchargeModel">Surcharge</a></li>
              <li><a class="dropdown-item" href="<?php echo e(route('users.update-password.edit')); ?>">Change Password</a></li>
            </ul>
          </li>
          <?php endif; ?>
        </ul>
        <span class="navbar-text mt-1 pt-0">
          <form action="<?php echo e(route('logout')); ?>" method="post">
              <?php echo csrf_field(); ?>
              <button type="submit" class="btn btn-link text-danger" id="logoutBtn">
                <i data-feather="log-out" class="feather-16 m-1"></i> Logout
              </button>
          </form>
        </span>
      </div>
    </div>
  </nav>

<?php if(auth()->guard()->check()): ?>
      <?php echo $__env->make('templates.water-rate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->make('templates.surcharge', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>

  <style>
    #logoutBtn{
      text-decoration: none;
      color:rgba(255,255,255,.55);
      cursor: pointer;
      text-align: left;
      padding: 0;
    }
    #logoutBtn:hover{
      color:#fff;
    }
    .navbar-text{
      height:3.1rem;
    }

  </style>


<?php /**PATH D:\jv file\websites\watersystemv2\resources\views/layout/nav.blade.php ENDPATH**/ ?>