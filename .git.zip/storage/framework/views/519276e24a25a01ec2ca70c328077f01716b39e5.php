<div class="col-12 col-md-3 mt-3">
    <!-- Very little is needed to make a happy life. - Marcus Antoninus -->
    <div class="card shadow-sm rounded-lg dashboard-card">
        <div class="card-body">
            <i data-feather="<?php echo e($icon); ?>" class=""></i>
            <h3 class="card-title text-end"><?php echo e($count); ?></h3>
            <p class="card-text text-end"><?php echo e($title); ?></p>
            <a href="<?php echo e($url); ?>" class="stretched-link"></a>
        </div>
    </div>
</div>
<?php /**PATH /Users/ccsit/Desktop/website/watersystemv2/resources/views/components/dashboard-card.blade.php ENDPATH**/ ?>