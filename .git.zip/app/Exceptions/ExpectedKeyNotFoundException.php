<?php

namespace App\Exceptions;

use Exception;

class ExpectedKeyNotFoundException extends Exception
{
    //
}
